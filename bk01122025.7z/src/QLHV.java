public class QLHV {
	public static void main(String[] args) {
		HVMain.main(null);
	}
}